define(["vue"],function(Vue){
  var navigator = new Vue();

  return navigator;
});


