define(["vue"],function(Vue){
    return {
        template:'\
            <div class="mt-table">\
                <div class="mt-table-thead">\
                    <table>\
                        <slot name="thead"></slot>\
                    </table>\
                </div>\
                <div class="mt-table-tbody">\
                    <table>\
                        <slot></slot>\
                    </table>\
                </div>\
            </div>\
        '
    }
});