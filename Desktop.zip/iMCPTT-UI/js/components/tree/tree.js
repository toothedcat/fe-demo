define(['vue','js/components/checkbox/checkbox.js'],function(Vue,Checkbox){
    var TreeItem = {
        name:'tree-item',
        template:'\
            <li class="mt-tree-item">\
                <div class="mt-tree-node"\
                    @dblclick="toggle"\
                    @mouseover="mouseoverHandler"\
                    @mouseout="mouseoutHandler"\
                    draggable="true"\
                    @dragstart="dragHandler"\
                >\
                    <div :class="wholerowCls">\
                        <checkbox class="mt-tree-checkbox" :checked="model.checked" />\
                    </div>\
                    <span :class="typeCls"></span>\
                    <span class="mt-tree-text">{{model.name}}</span>\
                </div>\
                <ul v-show="open" v-if="isFolder">\
                    <tree-item :model="model" v-for="model in model.children">\
                    </tree-item>\
                </ul>\
            </li>\
        ',
        props:['model'],
        data:function(){
            return {
                open:this.model.open ?true:false,
                hover:false
            };
        },
        computed:{
            isFolder:function(){
                return this.model.children && this.model.children.length;
            },
            arrowCls:function(){
                return {
                    'mt-tree-arrow':true,
                    'mt-tree-arrow-expand':this.open,
                    'mt-tree-arrow-hidden':!this.isFolder
                };
            },
            typeCls:function(){
                return {
                    'mt-tree-type':true,
                    'mt-tree-type-disabled':this.disabled
                }
            },
            wholerowCls:function(){
                return {
                    'mt-tree-wholerow':true,
                    'mt-tree-wholerow-hover':this.hover
                };
            }
        },
        methods:{
            toggle:function(){
                this.open = !this.open;
            },
            mouseoverHandler:function(){
                this.hover = true;
            },
            mouseoutHandler:function(){
                this.hover = false;
            },
            dragHandler:function(e){
                e.dataTransfer.setData('name',this.model.name);
                e.dataTransfer.setData('id',new Date().getTime().toString());
            }
        },
        components:{
            'checkbox':Checkbox
        }
    };
    return {
        template:'\
            <ul class="mt-tree">\
              <tree-item\
                :model="treeData">\
              </tree-item>\
            </ul>\
        ',
        props:['treeData'],
        components:{
            'tree-item':TreeItem
        }
    }
});