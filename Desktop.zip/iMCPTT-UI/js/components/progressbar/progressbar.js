define(['vue'],function(Vue){

});