define(["vue","js/components/tree/tree.js","js/app/schedule/dialoglayer/callpanel.js"],
    function(Vue,Tree,CallPanel){
    return {
        template:'\
            <div class="schedule-panel">\
                <div class="schedule-toolbar">\
                    <div class="schedule-controlbar clearfix" v-if="!search">\
                        <div class="controlbar-mulselect">\
                            <i></i>\
                            <span>多选呼叫</span>\
                        </div>\
                        <div class="controlbar-rearrange">\
                            <i></i>\
                            <span>动态重组</span>\
                        </div>\
                        <div class="controlbar-search">\
                            <i @click="searchChange(true)"></i>\
                        </div>\
                    </div>\
                    <div class="schedule-searchbar" v-else>\
                        <input placeholder="请输入搜索内容" class="searchbar-text" type="text" />\
                        <button class="searchbar-close" @click="searchChange(false)">\
                        </button>\
                    </div>\
                </div>\
                <div class="schedule-tree">\
                    <tree :tree-data="treeData"></tree>\
                </div>\
                <div class="schedule-callpanel">\
                    <call-panel canClose="false"></call-panel>\
                </div>\
            </div>\
        ',
        data:function(){
            var treeData = {
                name:'湖南铁路公安',
                children:[{
                    name:'长沙南所',
                    children:[{
                        name:'开福警务区',
                        children:[{
                            name:'警员A'
                        },{
                            name:'警员B'
                        },{
                            name:'警员C'
                        },{
                            name:'警员D'
                        },{
                            name:'警员E'
                        }]
                    }]
                },{
                    name:'邵阳南所',
                    children:[{
                        name:'纳米警务区',
                        children:[{
                            name:'警员A'
                        },{
                            name:'警员B'
                        },{
                            name:'警员C'
                        },{
                            name:'警员D'
                        },{
                            name:'警员E'
                        }]
                    }]
                },{
                    name:'湘潭北所',
                    children:[{
                        name:'乌拉警务区',
                        children:[{
                            name:'警员A'
                        },{
                            name:'警员B'
                        },{
                            name:'警员C'
                        },{
                            name:'警员D'
                        },{
                            name:'警员E'
                        }]
                    }]
                }]
            };
            return {
                'treeData':treeData,
                'search':false
            };
        },
        components:{
            tree:Tree,
            'call-panel':CallPanel
        },
        methods:{
            searchChange:function(val){
                this.search = val;
            }
        }
    };
});