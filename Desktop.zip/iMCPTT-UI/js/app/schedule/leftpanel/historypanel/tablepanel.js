define(["vue","js/components/table/table.js","js/components/playbar/playbar.js"],
    function(Vue,Table,PlayBar){
    var Row = {
        template:'\
            <tr>\
                <td width="25%">{{rowData.time}}</td>\
                <td width="25%">{{rowData.initiative}}</td>\
                <td width="25%">{{rowData.passtive}}</td>\
                <td width="25%">{{rowData.timespan}}</td>\
            </tr>\
        ',
        props:["rowData"],
        data:function(){
            return {
            };
        },
        computed:{

        },
        methods:{

        }
    }
    var HistoryTable = {
        props:['tableData'],
        template:'\
            <custom-table>\
                <thead slot="thead">\
                    <tr>\
                        <th width="25%">时间</th>\
                        <th width="25%">主叫</th>\
                        <th width="25%">被叫</th>\
                        <th width="25%">时长</th>\
                    </tr>\
                </thead>\
                <tbody>\
                    <custom-row v-for="row in tableData" :rowData="row"></custom-row>\
                </tbody>\
            </custom-table>\
        ',
        components:{
            'custom-table':Table,
            'custom-row':Row
        }
    };
    return {
        template:'\
            <div class="history-tablepanel">\
                <div class="toolbar">\
                    <div class="searchdesc">\
                        <span class="text">最近</span>\
                        <span class="select">24小时</span>\
                        <span class="text">记录</span>\
                    </div>\
                    <button class="search"></button>\
                </div>\
                <div class="history-table">\
                    <history-table :tableData="tableData"></history-table>\
                </div>\
                <div class="history-play">\
                    <play-bar \
                        @play="playHandler" \
                        @pause="pauseHandler" \
                        @rewind="rewindHandler"\
                        @forward="forwardHandler"\
                    />\
                </div>\
            </div>\
        ',
        data:function(){
            return {
                tableData:[{
                    time:'11.11',
                    initiative:'警员A',
                    passtive:'长沙南所',
                    timespan:'00:15'
                },{
                    time:'11.11',
                    initiative:'警员B',
                    passtive:'长沙南所',
                    timespan:'00:15'
                },{
                    time:'11.11',
                    initiative:'警员C',
                    passtive:'长沙南所',
                    timespan:'00:15'
                },{
                    time:'11.11',
                    initiative:'警员D',
                    passtive:'长沙南所',
                    timespan:'00:15'
                },{
                    time:'11.11',
                    initiative:'警员E',
                    passtive:'长沙南所',
                    timespan:'00:15'
                }]
            }
        },
        components:{
            'history-table':HistoryTable,
            'play-bar':PlayBar
        },
        methods:{
            playHandler:function(){
                alert('play')
            },
            pauseHandler:function(){
                alert("pause")
            },
            forwardHandler:function(){
                alert("forward")
            },
            rewindHandler:function(){
                alert("rewind")
            }
        }
    }
});