define(["vue"],function(Vue){
    return {
        template:'\
            <div class="history-detailpanel">\
                <div class="toolbar"></div>\
            </div>\
        '
    }
});