define(["vue"],function(Vue){
    return {
        template:'<div>logpanel</div>'
    }
});