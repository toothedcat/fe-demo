define(["vue"],function(Vue){
    return {
        template:'\
            <div class="historyalert">\
                <div class="title">\
                    <span class="symbol"><i></i></span>\
                    <span class="title-text">历史告警(3)</span>\
                    <button class="close" @click="closeHandler"></button>\
                    <button class="search" @click="searchChange(true)"></button>\
                </div>\
                历史告警\
            </div>\
        ',
        methods:{
            closeHandler:function(){
                this.$emit('close');
            }
        }
    }
});