define(["vue"],function(Vue){
    return {
        props:{
            "callInfo":{
                type:Object,
                default:{}
            }
        },
        template:'\
            <div class="callpanel" :style="panelStyle">\
                <div class="callpanel-wave"></div>\
                <i class="callpanel-profile"></i>\
                <div class="callpanel-desc">\
                    <div class="callpanel-name">开福警务区</div>\
                    <div class="callpanel-info">\
                        <span class="callpanel-text">96/188</span>\
                        <span class="callpanel-time">00:09</span>\
                    </div>\
                </div>\
                <button class="callpanel-audio"></button>\
                <button class="callpanel-mute"></button>\
                <button class="callpanel-hangup"></button>\
                <button class="callpanel-vedio"></button>\
                <button class="callpanel-add"></button>\
            </div>\
        ',
        computed:{
            panelStyle:function(){
                return {
                    left:this.callInfo.posX,
                    top:this.callInfo.posY
                }
            }
        },
        methods:{
            closeHandler:function(){
                this.$emit("closePanel",this.callInfo.id);
            }
        }
    }
});