/* 右键菜单管理，在window上注册事件，统一关闭右键菜单 */
define(function(){
    var ContextManager = function(){
        this.contextMenus = [];
    };
    // 对需要contextManager管理的右键菜单注册
    ContextManager.prototype.registerContextMenu = function(contextmenu){
        if(contextmenu.hide && typeof contextmenu.hide === 'function'){
            this.contextMenus.push(contextmenu);
        }
        else{
            throw new Error('try to register a wrong contextmenu');
        }
    };
    // 解除注册
    ContextManager.prototype.unRegisterContextMenu = function(contextmenu){
        var index = this.contextMenus.indexOf(contextmenu);
        if(index >= 0){
            this.contextMenus.splice(index,1);
        }
    };
    // 判断是否注册
    ContextManager.prototype.isContextMenuRegistered = function(contextmenu){
        return this.contextMenus.indexOf(contextmenu) >=0?true:false;
    };
    // 隐藏所有注册的右键菜单
    ContextManager.prototype.hide = function(){
        this.contextMenus.forEach(function(contextmenu){
            contextmenu.hide();
        });
    };

    var contextManager = new ContextManager();

    window.onclick = function(){
        contextManager.hide();
    };

    window.onmousewheel = function(){
        contextManager.hide();
    };

    return contextManager;
});