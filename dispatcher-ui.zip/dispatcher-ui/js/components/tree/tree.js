define(['vue','js/components/checkbox/checkbox.js',
    "../contextmenu/contextmenu.js"],
function(Vue,Checkbox,ContextMenu){
    var TreeItem = {
        name:'tree-item',
        template:'\
            <li class="mt-tree-item">\
                <div class="mt-tree-node"\
                    @dblclick="toggle"\
                    @mouseover="mouseoverHandler"\
                    @mouseout="mouseoutHandler"\
                    draggable="true"\
                    @dragstart="dragHandler"\
                    @contextmenu="contextmenuHandler"\
                >\
                    <div :class="wholerowCls">\
                        <checkbox class="mt-tree-checkbox" :checked="model.checked" />\
                    </div>\
                    <span :class="typeCls"></span>\
                    <span class="mt-tree-text">{{model.name}}</span>\
                </div>\
                <ul v-show="open" v-if="isFolder">\
                    <tree-item \
                        :model="model" \
                        v-for="model in model.children" \
                        @contextmenu="childcontextmenuHandler"\
                    >\
                    </tree-item>\
                </ul>\
            </li>\
        ',
        props:['model'],
        data:function(){
            return {
                open:this.model.open ?true:false,
                hover:false,
                contextmenuType:this.model.type == 0 ? 'user':'group'
            };
        },
        computed:{
            isFolder:function(){
                return this.model.children && this.model.children.length;
            },
            arrowCls:function(){
                return {
                    'mt-tree-arrow':true,
                    'mt-tree-arrow-expand':this.open,
                    'mt-tree-arrow-hidden':!this.isFolder
                };
            },
            typeCls:function(){
                return {
                    'mt-tree-type':true,
                    'mt-tree-type-user':this.model.type == 0,// 普通用户
                    'mt-tree-type-group':this.model.type == 1,// 普通群组
                    'mt-tree-type-disabled':this.disabled // 离线用户
                }
            },
            wholerowCls:function(){
                return {
                    'mt-tree-wholerow':true,
                    'mt-tree-wholerow-hover':this.hover
                };
            }
        },
        methods:{
            toggle:function(){
                this.open = !this.open;
            },
            mouseoverHandler:function(){
                this.hover = true;
            },
            mouseoutHandler:function(){
                this.hover = false;
            },
            dragHandler:function(e){
                var obj = {
                    name:this.model.name,
                    id:this.model.id
                };
                var str = window.JSON.stringify(obj)
                e.dataTransfer.setData('text',str);
            },
            contextmenuHandler:function(e){
                e.preventDefault();
                this.$emit('contextmenu',e.clientX,e.clientY,this.model);
            },
            childcontextmenuHandler:function(x,y,model){
                this.$emit('contextmenu',x,y,model);
            }
        },
        components:{
            'checkbox':Checkbox
        }
    };
    return {
        template:'\
            <ul class="mt-tree">\
                <contextmenu ref="contextmenu" @menuclick="menuclickHandler" />\
                <tree-item\
                    :model="treeData" \
                    @contextmenu="contextmenuHandler"\
                />\
            </ul>\
        ',
        props:['treeData'],
        components:{
            'tree-item':TreeItem,
            'contextmenu':ContextMenu
        },
        methods:{
            contextmenuHandler:function(x,y,model){
                this.$refs.contextmenu.showAt(x,y,model);
            },
            menuclickHandler:function(key,text,model){
                this.$emit('menuclick',key,text,model);
            }
        }
    };
});