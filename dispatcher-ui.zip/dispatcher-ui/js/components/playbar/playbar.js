/*
 * @desc 播放工具栏
 * @event play 点击播放后触发
 * @event pause 点击暂停后触发
 * @event forward 点击快进后触发
 * @event rewind 点击后退后触发
 */
define(['vue'],function(Vue){
    return {
        template:'\
            <div class="playbar">\
                <button class="forward" @click="forwardClick"></button>\
                <button :class="playCls" @click="playClick"></button>\
                <button class="rewind" @click="rewindClick"></button>\
            </div>\
        ',
        data:function(){
            return {
                paused:false
            };
        },
        computed:{
            playCls:function(){
                return {
                    "play":true,
                    "paused":this.paused
                };
            }
        },
        methods:{
            playClick:function(){
                if(this.paused == true){
                    this.$emit('pause');
                }else{
                    this.$emit('play');
                }
                this.paused = !this.paused;
            },
            rewindClick:function(){
                this.$emit('rewind');
            },
            forwardClick:function(){
                this.$emit('forward');
            }
        }
    }
});