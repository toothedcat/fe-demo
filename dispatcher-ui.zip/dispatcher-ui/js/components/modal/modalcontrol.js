define(["vue"],function(Vue){
    var ModalControl = function(){
        var modalEl = window.document.querySelector('#vue-modal');
        this.vm = new Vue({
            el:modalEl,
            template:'\
                <div :class="modalCls">\
                    <custom-dialog @close="dialogClose" :options="dialogOptions" />\
                </div>\
            ',
            data:function(){
                return {
                    active:false,
                    dialogOptions:{}
                };
            },
            computed:{
                modalCls:function(){
                    debugger
                    return {
                        "mt-modal":true,
                        "mt-modal-active":this.active
                    };
                }
            },
            components:{
                'custom-dialog':{template:'<div></div>'}
            },
            methods:{
                show:function(Dialog,options){
                    this.$options.components['custom-dialog'] = Dialog;
                    this.active = true;
                    this.dialogOptions = options;
                },
                dialogClose:function(){
                    this.close();
                },
                close:function(){
                    debugger
                    this.$options.components['custom-dialog'] = {template:'<div></div>'};
                    this.$data.active = false;
                    this.dialogOptions = {};

                }
            }
        });
    };

    ModalControl.prototype.showDialog = function(Dialog,options){
        //this.vm.close();
        this.vm.show(Dialog,options);
    };

    ModalControl.prototype.close = function(){
        this.vm.close();
    };

    var modalControl = new ModalControl();
    return modalControl;
});