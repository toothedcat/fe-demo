define(["vue"],function(Vue){
    return {
        template:'\
            <div :class="modalCls" v-show="modalShow">\
                <slot></slot>\
            </div>\
        ',
        data:function(){
            return {
                modalShow:false
            };
        },
        computed:{
            modalCls:function(){
                return {
                    "mt-modal":true,
                    "mt-modal-active":this.modalShow
                };
            }
        },
        methods:{
            show:function(){
                this.modalShow = true;
            },
            close:function(){
                this.modalShow = false;
            }
        }
    };
});