/*
 * 右键菜单
 * @prop [String] type 制定菜单的类型，对不同的用户类型生成不同的菜单项
 * @prop [event] menuclick 当点击菜单项时触发，其第一个参数为菜单项的key，第二个参数为菜单项的text
 */
define(["js/utils/contextmanager.js"],function(contextManager){
    return {
        template:'\
            <ul :class="menuCls" :style="menuStyle">\
                <li v-for="item in itemArr" @click="itemClick(item.key,item.text)">{{item.text}}</li>\
            </ul>\
        ',
        props:{
            'type':{
                default:'user'
            }
        },
        data:function(){
            return {
                left:0,
                top:0,
                show:false,
                menuType:this.type,
                typeMap:{
                    '0':'user',
                    '1':'group'
                },
                contextModel:null
            };
        },
        mounted:function(){
            if(!contextManager.isContextMenuRegistered(this)){
                contextManager.registerContextMenu(this);
            }
        },
        beforeDestroy:function(){
            contextManager.unRegisterContextMenu(this);
        },
        computed:{
            menuCls:function(){
                return {
                    'mt-contextmenu':true,
                    'mt-contextmenu-hide':!this.show
                };
            },
            menuStyle:function(){
                return {
                    left:this.left,
                    top:this.top
                };
            },
            itemArr:function(){
                var itemArr=null;
                if(this.menuType === 'user'){
                    itemArr = [{
                        key:'dispatch',
                        text:'调度'
                    },{
                        key:'locate',
                        text:'定位'
                    },{
                        key:'callhistory',
                        text:'呼叫历史'
                    },{
                        key:'trace',
                        text:'历史轨迹'
                    }];
                }else{
                    itemArr = [{
                        key:'dispatch',
                        text:'调度'
                    },{
                        key:'callhistory',
                        text:'呼叫历史'
                    }];
                }
                return itemArr;
            }
        },
        methods:{
            showAt:function(x,y,model){
                this.show = true;
                this.left = x;
                this.top = y;
                this.menuType = this.typeMap[model.type];
                this.contextModel = model;
            },
            hide:function(){
                this.show = false;
            },
            itemClick:function(key,text){
                this.$emit('menuclick',key,text,this.contextModel);
            }
        }
    };
});