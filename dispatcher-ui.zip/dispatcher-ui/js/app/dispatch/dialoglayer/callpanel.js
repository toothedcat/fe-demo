define(["vue"],function(Vue){
    return {
        props:{
            "callInfo":{
                type:Object,
                default:{}
            },
            "canClose":{
                type:Boolean,
                default:false
            }
        },
        template:'\
            <div class="callpanel"\
                :style="panelStyle"\
                @mousedown="mousedownHandler"\
                @mousemove="mousemoveHandler"\
                @mouseup="mouseupHandler"\
            >\
                <div class="callpanel-wave"></div>\
                <i class="callpanel-profile"></i>\
                <i class="callpanel-close" v-if="canClose" @click="closeClick"></i>\
                <div class="callpanel-desc">\
                    <div class="callpanel-name">开福警务区</div>\
                    <div class="callpanel-info">\
                        <span class="callpanel-text">96/188</span>\
                        <span class="callpanel-time">00:09</span>\
                    </div>\
                </div>\
                <button class="callpanel-audio"></button>\
                <button class="callpanel-mute"></button>\
                <button class="callpanel-hangup"></button>\
                <button class="callpanel-vedio"></button>\
                <button class="callpanel-add"></button>\
            </div>\
        ',
        data:function(){
            return {
                left:this.callInfo.posX||0,
                top:this.callInfo.posY||0
            };
        },
        computed:{
            panelStyle:function(){
                return {
                    left:this.left,
                    top:this.top
                };
            }
        },
        methods:{
            closeClick:function(){
                debugger
                this.$emit("closePanel",this.callInfo.id);
            },
            mousedownHandler:function(e){
                this.dragEnable = true;
                this.currentY = e.clientY;
                this.currentX = e.clientX;
                this.currentLeft = this.left;
                this.currentTop = this.top;
                e.preventDefault();
            },
            mousemoveHandler:function(e){
                // 只有在地图上悬浮的可以拖动
                if(this.dragEnable&&this.canClose){
                    var disX = e.clientX - this.currentX;
                    var disY = e.clientY - this.currentY;
                    this.left = this.currentLeft + disX;
                    this.top = this.currentTop + disY;
                }
            },
            mouseupHandler:function(){
                this.dragEnable = false;
            }
        }
    };
});