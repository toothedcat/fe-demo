define(["vue","./currentalert.js","./historyalert.js","./realmonitor.js"],
function(Vue,CurrentAlert,HistoryAlert,RealMonitor){
    return {
        template:'\
            <div class="bottompanel" @dragover="dragoverHandler">\
                <div class="bottompanel-content" v-if="isExpanded">\
                    <keep-alive>\
                        <component :is="currentView" @close="closeHandler"></component>\
                    </keep-alive>\
                </div>\
            </div>\
        ',
        props:["eventBus"],
        mounted:function(){
            this.eventBus.$on('bottomTabChange',this.tabChange);
        },
        beforeDestroy:function(){
            this.eventBus.$off('bottomTabChange',this.tabChange);
        },
        data:function(){
            return{
                isExpanded:false,
                tabActive:1,
                currentView:'current-alert'
            };
        },
        methods:{
            tabChange:function(tab){
                this.tabActive = tab;
                if(tab === 1){
                    this.isExpanded = true;
                    this.currentView = 'current-alert';
                }else if(tab === 2){
                    this.isExpanded = true;
                    this.currentView = 'history-alert';
                }else if(tab === 3){
                    this.isExpanded = true;
                    this.currentView = 'real-monitor';
                }
            },
            closeHandler:function(){
                this.isExpanded = false;
                this.eventBus.$emit("bottomclose");
            },
            dragoverHandler:function(e){
                this.$emit("dragover",e);
            }
        },
        components:{
            'current-alert':CurrentAlert,
            'history-alert':HistoryAlert,
            'real-monitor':RealMonitor
        }
    };
});