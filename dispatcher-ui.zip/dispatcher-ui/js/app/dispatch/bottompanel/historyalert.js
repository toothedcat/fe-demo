define(["vue","js/components/table/table.js"],function(Vue,Table){
    var Row = {
        template:'\
            <tr>\
                <td width="15%">{{rowData.area}}</td>\
                <td width="15%">{{rowData.obj}}</td>\
                <td width="10%" :class="alertCls">{{rowData.type}}</td>\
                <td width="15%">{{rowData.time}}</td>\
                <td width="15%">{{rowData.type}}</td>\
                <td width="15%">{{rowData.confirm}}</td>\
                <td width="15%">{{rowData.remark}}</td>\
            </tr>\
        ',
        props:["rowData"],
        data:function(){
            return {
                confirmShow:false
            };
        },
        computed:{
            alertCls:function(){
                return {
                    'emmergency':this.rowData.type === 1,
                    'outrange':this.rowData.type === 2,
                    'hold':this.rowData.type === 3,
                    'disabled':this.rowData.type === 4
                };
            }
        },
        methods:{
            showConfirm:function(){
                this.confirmShow = true;
            }
        }
    };
    var AlertTable = {
        props:['tableData'],
        template:'\
            <custom-table>\
                <thead slot="thead">\
                    <tr>\
                        <th width="15%">警务区</th>\
                        <th width="15%">告警对象</th>\
                        <th width="10%">告警类型</th>\
                        <th width="15%">告警时间</th>\
                        <th width="15%">告警时长</th>\
                        <th width="15%">确认人</th>\
                        <th width="15%">备注</th>\
                    </tr>\
                </thead>\
                <tbody>\
                    <custom-row v-for="row in tableData" :rowData="row"></custom-row>\
                </tbody>\
            </custom-table>\
        ',
        components:{
            'custom-table':Table,
            'custom-row':Row
        }
    };
    var tableData = [{
        area:'湘潭北所',
        obj:'警员A',
        type:1,// 1-紧急告警 2-越界告警 3-长时间不动 4-离线
        time:'12/19 10:36'
    },{
        area:'湘潭北所',
        obj:'警员B',
        type:2,// 1-紧急告警 2-越界告警 3-长时间不动
        time:'12/19 10:36'
    },{
        area:'湘潭北所',
        obj:'警员C',
        type:3,// 1-紧急告警 2-越界告警 3-长时间不动
        time:'12/19 10:36'
    },{
        area:'湘潭北所',
        obj:'警员D',
        type:4,// 1-紧急告警 2-越界告警 3-长时间不动
        time:'12/19 10:36'
    },{
        area:'湘潭北所',
        obj:'警员E',
        type:4,// 1-紧急告警 2-越界告警 3-长时间不动
        time:'12/19 10:36'
    },{
        area:'湘潭北所',
        obj:'警员F',
        type:2,// 1-紧急告警 2-越界告警 3-长时间不动
        time:'12/19 10:36'
    }];
    return {
        template:'\
            <div class="historyalert">\
                <div class="title">\
                    <span class="symbol"><i></i></span>\
                    <span class="title-text">历史告警(3)</span>\
                    <button class="close" @click="closeHandler"></button>\
                    <button class="search" @click="searchChange(true)"></button>\
                </div>\
                <div class="content">\
                    <alert-table :tableData=tableData></alert-table>\
                </div>\
            </div>\
        ',
        data:function(){
            return {
                tableData:tableData
            };
        },
        methods:{
            closeHandler:function(){
                this.$emit('close');
            },
            searchChange:function(){

            }
        },
        components:{
            'alert-table':AlertTable
        }
    }
});