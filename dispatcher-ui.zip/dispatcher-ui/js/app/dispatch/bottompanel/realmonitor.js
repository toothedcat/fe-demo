define(["vue","js/components/table/table.js"],function(Vue,Table){
    var Row = {
        template:'\
            <tr>\
                <td width="15%">{{rowData.area}}</td>\
                <td width="15%">{{rowData.obj}}</td>\
                <td width="15%">{{rowData.longitude}}</td>\
                <td width="15%">{{rowData.latitude}}</td>\
                <td width="15%">{{rowData.speed}}</td>\
                <td width="10%">{{rowData.direction}}</td>\
                <td width="15%">{{rowData.time}}</td>\
            </tr>\
        ',
        props:["rowData"],
        data:function(){
            return {
                confirmShow:false
            };
        },
        computed:{
            alertCls:function(){
                return {
                    'emmergency':this.rowData.type === 1,
                    'outrange':this.rowData.type === 2,
                    'hold':this.rowData.type === 3,
                    'disabled':this.rowData.type === 4
                }
            }
        },
        methods:{
            showConfirm:function(){
                this.confirmShow = true;
            }
        }
    }
    var AlertTable = {
        props:['tableData'],
        template:'\
            <custom-table>\
                <thead slot="thead">\
                    <tr>\
                        <th width="15%">警务区</th>\
                        <th width="15%">对象</th>\
                        <th width="15%">经度</th>\
                        <th width="15%">纬度</th>\
                        <th width="15%">速度</th>\
                        <th width="10%">方向</th>\
                        <th width="15%">时间</th>\
                    </tr>\
                </thead>\
                <tbody>\
                    <custom-row v-for="row in tableData" :rowData="row"></custom-row>\
                </tbody>\
            </custom-table>\
        ',
        components:{
            'custom-table':Table,
            'custom-row':Row
        }
    };
    var tableData = [{
        area:'湘潭北所',
        obj:'警员A',
        longitude:'112.35',
        latitude:'32.56',
        speed:'23m/s',
        direction:'45',
        time:'12/19 10:36'
    },{
        area:'湘潭北所',
        obj:'警员B',
        longitude:'112.35',
        latitude:'32.56',
        speed:'23m/s',
        direction:'45',
        time:'12/19 10:36'
    },{
        area:'湘潭北所',
        obj:'警员C',
        longitude:'112.35',
        latitude:'32.56',
        speed:'23m/s',
        direction:'45',
        time:'12/19 10:36'
    },{
        area:'湘潭北所',
        obj:'警员D',
        longitude:'112.35',
        latitude:'32.56',
        speed:'23m/s',
        direction:'45',
        time:'12/19 10:36'
    },{
        area:'湘潭北所',
        obj:'警员E',
        longitude:'112.35',
        latitude:'32.56',
        speed:'23m/s',
        direction:'45',
        time:'12/19 10:36'
    },{
        area:'湘潭北所',
        obj:'警员F',
        longitude:'112.35',
        latitude:'32.56',
        speed:'23m/s',
        direction:'45',
        time:'12/19 10:36'
    }]
    return {
        template:'\
            <div class="realmonitor">\
                <div class="title">\
                    <span class="symbol"><i></i></span>\
                    <span class="title-text">实时监控(3)</span>\
                    <button class="close" @click="closeHandler"></button>\
                    <button class="search" @click="searchChange(true)"></button>\
                </div>\
                <div class="content">\
                    <alert-table :tableData=tableData></alert-table>\
                </div>\
            </div>\
        ',
        data:function(){
            return {
                tableData:tableData
            };
        },
        methods:{
            closeHandler:function(){
                this.$emit('close');
            },
            searchChange:function(){

            }
        },
        components:{
            'alert-table':AlertTable
        }
    }
});