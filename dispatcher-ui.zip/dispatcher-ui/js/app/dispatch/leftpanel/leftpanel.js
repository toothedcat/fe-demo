define(["vue","./schedulepanel/schedulepanel.js","./historypanel/historypanel.js","./logpanel/logpanel.js","../dialoglayer/callpanel.js"],
    function(Vue,SchedulePanel,HistoryPanel,LogPanel,CallPanel){
    return {
        template:'\
            <div :class="leftpanelCls" @dragover="dragoverHandler">\
                <div class="leftpanel-header">\
                    <div class="header-profile">\
                        <i class="header-logo"></i>\
                        <button class="header-config"></button>\
                        <button class="header-logout"></button>\
                        <span class="header-name">LIXIAOLIAN</span>\
                    </div>\
                    <div class="header-timestamp">{{timeObj.hour}}:{{timeObj.minute}} {{timeObj.month}}月{{timeObj.date}}日 {{timeObj.day}}</div>\
                </div>\
                <div class="leftpanel-switch clearfix">\
                    <span class="leftpanel-switch-tab"\
                        v-bind:class="{\'leftpanel-switch-tab-active\':tabActive===1?true:false}"\
                        @click="tabClickHandler(1)">\
                        <span class="switch-tab-text">调度</span>\
                    </span>\
                    <span class="leftpanel-switch-tab"\
                        v-bind:class="{\'leftpanel-switch-tab-active\':tabActive===2?true:false}"\
                        @click="tabClickHandler(2)">\
                        <span class="switch-tab-text">历史</span>\
                    </span>\
                    <span class="leftpanel-switch-tab"\
                        v-bind:class="{\'leftpanel-switch-tab-active\':tabActive===3?true:false}"\
                        @click="">\
                        <span class="switch-tab-text">消息</span>\
                    </span>\
                </div>\
                <div class="leftpanel-content">\
                    <keep-alive>\
                        <component :is="currentView"></component>\
                    </keep-alive>\
                </div>\
                <div class="leftpanel-footer">\
                    <div class="leftpanel-bottomswitch">\
                        <button class="leftpanel-bottomswitch-tab" @click="bottomTabChange(1)"></button>\
                        <button class="leftpanel-bottomswitch-tab" @click="bottomTabChange(2)"></button>\
                        <button class="leftpanel-bottomswitch-tab" @click="bottomTabChange(3)"></button>\
                    </div>\
                    <span class="leftpanel-toggle" @click="toggleHandler"></span>\
                </div>\
            </div>\
        ',
        props:["eventBus"],
        mounted:function(){
            this.refreshTime();
            this.eventBus.$on("bottomclose",this.bottomcloseHandler);
        },
        beforeDestroy:function(){
            this.clearRefreshTime();
            this.eventBus.$off("bottomclose",this.bottomcloseHandler);
        },
        data:function(){
            return {
                currentView:'schedule-panel',
                tabActive:1,
                isExpanded:true,
                bottomExpanded:false,
                timeObj:this.getTimeObj()
            }
        },
        methods:{
            tabClickHandler:function(tab){
                this.tabActive = tab;
                if(tab === 1){
                    this.currentView = 'schedule-panel';
                }else if(tab === 2){
                    this.currentView = 'history-panel';
                }else if(tab === 3){
                    this.currentView = 'log-panel';
                }
            },
            bottomTabChange:function(tab){
                this.bottomExpanded = true;
                this.eventBus.$emit('bottomTabChange',tab);
            },
            bottomcloseHandler:function(){
                this.bottomExpanded = false;
            },
            toggleHandler:function(){
                this.isExpanded = !this.isExpanded;
            },
            dragoverHandler:function(e){
                this.$emit("dragover",e);
            },
            getTimeObj:function(){
                var date = new Date();
                var obj = {};
                obj.year = date.getFullYear();
                obj.month = date.getMonth()+1;
                obj.date = date.getDate();
                obj.day = new Array("星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六")[date.getDay()];
                obj.hour = date.getHours() < 10 ? "0" + date.getHours() : date.getHours();
                obj.minute = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
                obj.second = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
                return obj;
            },
            refreshTime:function(){
                var that = this;
                this.timeIntervalId = setInterval(function(){
                    that.timeObj = that.getTimeObj();
                },5000)
            },
            clearRefreshTime:function(){
                clearInterval(this.timeIntervalId);
            }
        },
        computed:{
            leftpanelCls:function(){
                return {
                    "leftpanel":true,
                    "leftpanel-collapse":!this.isExpanded,
                    "leftpanel-bottomexpanded":this.bottomExpanded
                };
            }
        },
        components:{
            'schedule-panel':SchedulePanel,
            'history-panel':HistoryPanel,
            'log-panel':LogPanel,
            'call-panel':CallPanel
        }
    }
});