define(["vue","./tablepanel.js","./detailpanel.js"],
    function(Vue,TablePanel,DetailPanel){
    return {
        template:'\
            <div class="history-panel">\
                <keep-alive>\
                    <component :is="currentView"></component>\
                </keep-alive>\
            </div>\
        ',
        data:function(){
            return{
                "currentView":'table-panel'
            }
        },
        components:{
            'table-panel':TablePanel,
            'detail-panel':DetailPanel
        }
    }
});