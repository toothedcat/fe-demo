define(["vue","js/components/tree/tree.js",
    "js/app/dispatch/dialoglayer/callpanel.js",
    "js/components/modal/modal.js",
    "js/app/dispatch/tracedialog/tracedialog.js",
    "js/app/dispatch/tracedialog/tracehistorydialog.js"],
function(Vue,Tree,CallPanel,Modal,TraceDialog,TraceHistoryDialog){
    return{
        template:'\
            <div class="schedule-panel">\
                <div class="schedule-toolbar">\
                    <div class="schedule-controlbar clearfix" v-if="!search">\
                        <div class="controlbar-mulselect">\
                            <i></i>\
                            <span>多选呼叫</span>\
                        </div>\
                        <div class="controlbar-rearrange">\
                            <i></i>\
                            <span>动态重组</span>\
                        </div>\
                        <div class="controlbar-search">\
                            <i @click="searchChange(true)"></i>\
                        </div>\
                    </div>\
                    <div class="schedule-searchbar" v-else>\
                        <input placeholder="请输入搜索内容" class="searchbar-text" type="text" />\
                        <button class="searchbar-close" @click="searchChange(false)">\
                        </button>\
                    </div>\
                </div>\
                <div class="schedule-tree">\
                    <tree :tree-data="treeData" @menuclick="menuclickHandler"></tree>\
                </div>\
                <div class="schedule-callpanel">\
                    <call-panel :canClose="false"></call-panel>\
                </div>\
                <modal ref="traceDialog">\
                    <trace-dialog \
                        :options="traceOptions" \
                        @query="traceDialogQuery" \
                        @close="traceDialogClose"\
                    />\
                </modal>\
                <modal ref="traceHistoryDialog">\
                    <tracehistory-dialog :options="traceHistoryOptions" @close="traceHistoryDialogClose" />\
                </modal>\
            </div>\
        ',
        data:function(){
            var treeData = {
                id:1,
                name:'湖南铁路公安',
                type:1,
                children:[{
                    id:2,
                    name:'长沙南所',
                    type:1,
                    children:[{
                        name:'开福警务区',
                        type:1,
                        children:[{
                            id:3,
                            name:'警员A',
                            type:0
                        },{
                            id:4,
                            name:'警员B',
                            type:0
                        },{
                            id:5,
                            name:'警员C',
                            type:0
                        },{
                            id:6,
                            name:'警员D',
                            type:0
                        },{
                            id:7,
                            name:'警员E',
                            type:0
                        }]
                    }]
                },{
                    id:8,
                    name:'邵阳南所',
                    type:1,
                    children:[{
                        id:9,
                        name:'纳米警务区',
                        type:1,
                        children:[{
                            id:10,
                            name:'警员A',
                            type:0
                        },{
                            id:11,
                            name:'警员B',
                            type:0
                        },{
                            id:12,
                            name:'警员C',
                            type:0
                        },{
                            id:13,
                            name:'警员D',
                            type:0
                        },{
                            id:14,
                            name:'警员E',
                            type:0
                        }]
                    }]
                },{
                    id:15,
                    name:'湘潭北所',
                    type:1,
                    children:[{
                        id:16,
                        name:'乌拉警务区',
                        type:1,
                        children:[{
                            id:17,
                            name:'警员A',
                            type:0
                        },{
                            id:18,
                            name:'警员B',
                            type:0
                        },{
                            id:19,
                            name:'警员C',
                            type:0
                        },{
                            id:20,
                            name:'警员D',
                            type:0
                        },{
                            id:21,
                            name:'警员E',
                            type:0
                        }]
                    }]
                }]
            };
            return {
                'treeData':treeData, //
                'search':false, // 是否是搜索状态
                'traceOptions':{}, // trace窗口的配置项
                'traceHistoryOptions':{} // tracehistory窗口的配置项
            };
        },
        components:{
            'tree':Tree,
            'call-panel':CallPanel,
            'modal':Modal,
            'trace-dialog':TraceDialog,
            'tracehistory-dialog':TraceHistoryDialog
        },
        methods:{
            searchChange:function(val){
                this.search = val;
            },
            menuclickHandler:function(key,text,model){
                if(key === 'dispatch'){
                    // 调度
                }else if(key === 'callhistory'){
                    // 呼叫历史
                }else if(key === 'locate'){
                    // 定位
                }else if(key === 'trace'){
                    var options = {
                        name:model.name
                    };
                    this.traceOptions = options;
                    this.$refs.traceDialog.show();
                }
                //alert(key + "," + text+","+model.name);
            },
            traceDialogClose:function(){
                this.$refs.traceDialog.close();
            },
            traceDialogQuery:function(model){
                var options={
                    name:model.name
                };
                this.traceHistoryOptions = options;
                this.$refs.traceHistoryDialog.show();
            },
            traceHistoryDialogClose:function(){
                this.$refs.traceHistoryDialog.close();
            }
        }
    };
});