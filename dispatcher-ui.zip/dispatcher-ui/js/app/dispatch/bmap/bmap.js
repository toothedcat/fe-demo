define(["vue","./lib/skyleadMap.js"],function(Vue,SkyLeadMap){
    return {
        template:'\
            <div class="schedule-map" id="b-map"></div>\
        ',
        data:function(){
            return {};
        },
        mounted:function(){
            //var mcMap = new SkyLeadMap("b-map");
            //window.mcMap = mcMap;
            //mcMap.centerAndZoom(113.06355, 28.16236, 11);
        }
    };
});