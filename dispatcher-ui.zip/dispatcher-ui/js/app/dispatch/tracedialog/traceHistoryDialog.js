define(['vue','js/components/checkbox/checkbox.js','js/components/table/table.js'],
function(Vue,CheckBox,Table){
    var Row = {
        template:'\
            <tr>\
                <td width="16%">{{rowData.time}}</td>\
                <td width="20%">{{rowData.area}}</td>\
                <td width="16%">{{rowData.longitude}}</td>\
                <td width="16%">{{rowData.latitude}}</td>\
                <td width="16%">{{rowData.direction}}</td>\
                <td width="16%">{{rowData.speed}}</td>\
            </tr>\
        ',
        props:["rowData"],
        data:function(){
            return {

            };
        }
    };
    var TraceTable = {
        props:['tableData'],
        template:'\
            <custom-table>\
                <thead slot="thead">\
                    <tr>\
                        <th width="16%">时间</th>\
                        <th width="20%">位置描述</th>\
                        <th width="16%">经度</th>\
                        <th width="16%">纬度</th>\
                        <th width="16%">方向</th>\
                        <th width="16%">速度</th>\
                    </tr>\
                </thead>\
                <tbody>\
                    <custom-row v-for="row in tableData" :rowData="row"></custom-row>\
                </tbody>\
            </custom-table>\
        ',
        components:{
            'custom-table':Table,
            'custom-row':Row
        }
    };
    var tableData = [{
        area:'大新地铁站',
        longitude:'112.35',
        latitude:'32.56',
        speed:'23m/s',
        direction:'45',
        time:'12/19 10:36'
    },{
        area:'大新地铁站',
        longitude:'112.35',
        latitude:'32.56',
        speed:'23m/s',
        direction:'45',
        time:'12/19 10:36'
    },{
        area:'大新地铁站',
        longitude:'112.35',
        latitude:'32.56',
        speed:'23m/s',
        direction:'45',
        time:'12/19 10:36'
    },{
        area:'大新地铁站',
        longitude:'112.35',
        latitude:'32.56',
        speed:'23m/s',
        direction:'45',
        time:'12/19 10:36'
    },{
        area:'大新地铁站',
        longitude:'112.35',
        latitude:'32.56',
        speed:'23m/s',
        direction:'45',
        time:'12/19 10:36'
    },{
        area:'大新地铁站',
        longitude:'112.35',
        latitude:'32.56',
        speed:'23m/s',
        direction:'45',
        time:'12/19 10:36'
    },{
        area:'大新地铁站',
        longitude:'112.35',
        latitude:'32.56',
        speed:'23m/s',
        direction:'45',
        time:'12/19 10:36'
    },{
        area:'大新地铁站',
        longitude:'112.35',
        latitude:'32.56',
        speed:'23m/s',
        direction:'45',
        time:'12/19 10:36'
    },{
        area:'大新地铁站',
        longitude:'112.35',
        latitude:'32.56',
        speed:'23m/s',
        direction:'45',
        time:'12/19 10:36'
    }];

    return {
        template:'\
            <div :class="traceCls">\
                <div class="tracehisdialog-header">\
                    <div class="header-text">[{{options.name}}]历史轨迹</div>\
                    <button class="header-close" @click="closeClick"></button>\
                </div>\
                <div class="tracehisdialog-body">\
                    <div class="body-header">\
                        <div class="header-desc">2017/01/09 0:00-10:37共计86个轨迹点</div>\
                        <span class="header-requery">重新查询</span>\
                    </div>\
                    <div class="body-table">\
                        <trace-table :tableData="tableData"></trace-table>\
                    </div>\
                </div>\
                <div class="tracehisdialog-footer">\
                    <div class="footer-timeinterval">\
                        <span>播放间隔</span>\
                        <select name="" id="">\
                            <option value="0">0.5小时</option>\
                            <option value="1">1小时</option>\
                            <option value="2">2小时</option>\
                            <option value="3">3小时</option>\
                            <option value="4">5小时</option>\
                        </select>\
                    </div>\
                    <div class="footer-playbar">\
                        <button class="slower"></button>\
                        <button :class="playCls" @click="playClick"></button>\
                        <button class="faster"></button>\
                    </div>\
                    <div class="footer-allpath">\
                        全路径显示\
                    </div>\
                </div>\
            </div>\
        ',
        props:["options"],
        data:function(){
            return {
                tableData:tableData,
                paused:false
            };
        },
        computed:{
            traceCls:function(){
                return {
                    "tracehisdialog":true
                };
            },
            playCls:function(){
                return {
                    "play":true,
                    "paused":this.paused
                };
            }
        },
        components:{
            'checkbox':CheckBox,
            'trace-table':TraceTable
        },
        methods:{
            closeClick:function(){
                this.$emit('close');
            },
            playClick:function(){
                if(this.paused == true){
                    //pause
                }else{
                    //play
                }
                this.paused = !this.paused;
            }
        }
    };
});