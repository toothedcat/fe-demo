define(['vue','js/components/checkbox/checkbox.js'],
function(Vue,CheckBox){
    return {
        template:'\
            <div :class="traceCls">\
                <div class="tracedialog-header">\
                    <div class="header-text">[{{options.name}}]历史轨迹</div>\
                    <button class="header-close" @click="closeClick"></button>\
                </div>\
                <div class="tracedialog-body">\
                    <div class="tracedialog-timespan">\
                        <checkbox class="timespan-checkbox" id="today-check"></checkbox>\
                        <label class="timespan-label" for="today-check">今天</label>\
                        <checkbox class="timespan-checkbox" id="day-check"></checkbox>\
                        <label class="timespan-label" for="day-check">最近24小时</label>\
                        <checkbox class="timespan-checkbox" id="week-check"></checkbox>\
                        <label class="timespan-label" for="week-check">最近一周</label>\
                    </div>\
                    <div class="tracedialog-time tracedialog-starttime">\
                        <label for="" class="time-label">开始时间</label>\
                        <input type="text" />\
                    </div>\
                    <div class="tracedialog-time tracedialog-endtime">\
                        <label for="" class="time-label">结束时间</label>\
                        <input type="text" />\
                    </div>\
                </div>\
                <div class="tracedialog-footer">\
                    <button @click="cancelClick">取消</button>\
                    <button @click="queryClick">查询</button>\
                </div>\
            </div>\
        ',
        props:["options"],
        computed:{
            traceCls:function(){
                return {
                    "tracedialog":true
                };
            }
        },
        components:{
            'checkbox':CheckBox
        },
        methods:{
            closeClick:function(){
                this.$emit('close');
            },
            cancelClick:function(){
                this.$emit('close');
            },
            queryClick:function(){
                // do query
                this.$emit('query',{
                    name:this.options.name
                });
                this.$emit('close');
            }
        }
    };
});