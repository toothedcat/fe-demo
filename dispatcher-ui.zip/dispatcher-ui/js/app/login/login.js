define(["vue","js/utils/navigator.js"],function(Vue,navigator){
    return {
        template:'\
          <div class="login">\
              <div class="login-header">\
                <div class="login-logo"></div>\
              </div>\
              <div :class="footerCls">\
                <div class="footer-logo"></div>\
                <div class="footer-desc">深圳市国创通信技术有限公司保留所有权</div>\
                <div class="footer-info">\
                  <a href="">关于</a>|\
                  <a href="">帮助</a>\
                </div>\
              </div>\
              <div class="login-body">\
                  <div class="login-box" v-show="!config">\
                      <div class="login-user">\
                        <i></i>\
                        <input type="text" placeholder="账号或手机号">\
                      </div>\
                      <div class="login-password">\
                        <i></i>\
                        <input type="password" placeholder="密码">\
                      </div>\
                      <div class="login-btn">\
                         <i></i>\
                        <button @click="loginClick">登录</button>\
                      </div>\
                      <div class="config-btn">\
                        <button @click="configClick"></button>\
                      </div>\
                  </div>\
                  <div class="config-box" v-show="config">\
                      <div class="login-address">\
                        <i></i>\
                        <input type="text" placeholder="服务器地址">\
                      </div>\
                      <div class="login-port">\
                        <i></i>\
                        <input type="text" placeholder="端口号">\
                      </div>\
                      <div class="login-return">\
                         <i></i>\
                        <button @click="returnClick">返回</button>\
                      </div>\
                  </div>\
              </div>\
          </div>\
        ',
        data:function(){
            return {
                config:false
            };
        },
        methods:{
            loginClick:function(){
                //MCPTTClient.initConsole("192.168.0.99");
                //var ret = MCPTTClient.login(1,"13913999858","c3d418e9bea12c81c5728e5597558a92");

                navigator.$emit("navigate", "dispatch");
            },
            configClick:function(){
                this.config = true;
            },
            returnClick:function(){
                this.config = false;
            }
        },
        computed:{
          footerCls:function(){
            return {
              'login-footer':true
            }
          }
        }
    };
});